/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bpc;

/**
 *
 * @author LENOVO
 */
public class TestC {
    public static void main(String[] args) {
        //instantiate the C class
        C objC = new C();
        objC.showData();
        objC.showDataFromD();
        
        
    }
    
}
