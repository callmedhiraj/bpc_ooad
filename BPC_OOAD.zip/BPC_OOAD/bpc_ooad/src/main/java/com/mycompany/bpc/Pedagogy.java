/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bpc;

/**
 *
 * @author LENOVO
 */
public  abstract class Pedagogy {
    public abstract void teachingMethod();
    public abstract void anotherMethod();
    //some method that has some definition.
    public void counselling(){
        System.out.println("Couselling is Key!");
    }
    
}
