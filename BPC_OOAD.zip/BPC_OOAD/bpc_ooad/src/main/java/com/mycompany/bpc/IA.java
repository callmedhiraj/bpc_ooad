/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.bpc;

/**
 *
 * @author LENOVO
 */
public interface IA {
    public  static final Double  G = 9.8; //assign the value right here
    public void showData();
    
}
