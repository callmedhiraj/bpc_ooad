/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bpc;

/**
 *
 * @author LENOVO
 */
public class TestPedagogy {
    public static void main(String[] args) {
        //creating an object of abstract class, illegal
        ConcreteClass p = new ConcreteClass();
        p.teachingMethod();
}
}
