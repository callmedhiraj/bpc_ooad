/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bpc;

/**
 *
 * @author LENOVO
 */
public class ConcreteClass extends Pedagogy {
    @Override
    public void teachingMethod(){
        System.out.println("Reverse Psychology");
        
    }
    //own personal method
    public void secretTeacher(){
        System.out.println("I am a secret teacher teaching livlihood with books.");
    }
    @Override
    public void anotherMethod(){
        //do nothing
    }
    
}
