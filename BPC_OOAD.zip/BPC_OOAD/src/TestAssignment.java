
public class TestAssignment{
    public static void main(String[] args) {
        //create an object
        Assignment a1 = new Assignment();
    }
}