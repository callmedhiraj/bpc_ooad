/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package observer;

/**
 *
 * @author LENOVO
 */
import java.util.ArrayList;
import java.util.List;

public class MessagePublisher implements Subject {

    private List<BPCObserver> observers = new ArrayList<>();

    @Override
    public void attach(BPCObserver o) {
        observers.add(o);
    }

    @Override
    public void detach(BPCObserver o) {
        observers.remove(o);
    }

    @Override
    public void notifyUpdate(Message m) {
        for (BPCObserver o : observers) {
            o.update(m);
        }
    }

}
