/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package observer;

/**
 *
 * @author LENOVO
 */
public interface Subject
{
public void attach(BPCObserver o);
public void detach(BPCObserver o);
public void notifyUpdate(Message m);
}
